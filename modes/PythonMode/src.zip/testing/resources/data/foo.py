victory = 'yes'
